const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
// create our express app
const app = express();
var cors = require("cors");
app.use(cors());
// middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// route
const routes = require("./routes/Routes");
app.use("/", routes);
//start server
app.listen(8000, () => {
  console.log("listeniing at port:8000");
});
