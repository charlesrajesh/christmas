const express = require("express");
const dRoutes = express.Router();
const fs = require("fs");

const dataPath = "./db/donation.json";

// util functions

const saveData = (data) => {
  const stringifyData = JSON.stringify(data);
  fs.writeFileSync(dataPath, stringifyData);
};

const getData = () => {
  const jsonData = fs.readFileSync(dataPath);
  return JSON.parse(jsonData);
};

dRoutes.post("/data/adddata", (req, res) => {
  var existAccounts = getData();
  existAccounts.decoration.push(req.body.decoration);

  console.log(existAccounts);

  saveData(existAccounts);
  res.send({
    success: true,
    msg: " data added successfully",
    decoration: existAccounts.decoration,
  });
});

// Read - get all accounts from the json file
dRoutes.get("/data/list", (req, res) => {
  const accounts = getData();
  res.send(accounts);
});

module.exports = dRoutes;
