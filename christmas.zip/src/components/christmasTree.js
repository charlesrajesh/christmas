import ImageContainer from "./imageConatiner";
import LightsContainer from "./lightContainer";
import TreePath from "./treePath";

function ChristmasTree() {
  // const isGiftedAlready = JSON.parse(localStorage.getItem("gifted"));
  const isGiftedAlready = false
  return (
    <div className="tree-container">
      <svg viewBox="0 0 960 560" className="main-tree">
        <image
          x={"145"}
          y={"150"}
          height={"80"}
          width={"80"}
          className="no-pointer"
          href={"assets/decor/n.svg"}
        />
        <image
          x={"230"}
          y={"150"}
          height={"80"}
          width={"80"}
          className="no-pointer"
          href={"assets/decor/d.svg"}
        />
        <image
          x={"285"}
          y={"150"}
          height={"80"}
          width={"80"}
          className="no-pointer"
          href={"assets/decor/i.svg"}
        />
        <image
          x={"600"}
          y={"90"}
          height={"200"}
          width={"200"}
          className="no-pointer"
          href={"assets/decor/merry.svg"}
        />
	{!isGiftedAlready &&
	<image
          x={"-100"}
          y={"-70"}
          height={"250"}
          width={"250"}
          className="no-pointer"
          href={"assets/decor/scroll.svg"}
        />
	}
	<TreePath />
        <LightsContainer />
        <ImageContainer />
      </svg>
    </div>
  );
}

export default ChristmasTree;
