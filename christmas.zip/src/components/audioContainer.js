import { useEffect, useRef } from "react";

function AudioContainer() {
  const ref = useRef({ current: null });
  function musicPlay() {
    ref.current.play();
    ref.current.volume=0.1;
    document.removeEventListener("click", musicPlay);
  }

  useEffect(() => {
    ref.current.volume=0.1;
    document.addEventListener("click", musicPlay);
  }, []);

  return (
    <audio id="audio" ref={ref} autoPlay={true} loop={true}>
      <source src="music.mp3" type="audio/mpeg" />
      <embed src="music.mp3" autostart="true" loop={true} hidden={true} />
    </audio>
  );
}

export default AudioContainer;
