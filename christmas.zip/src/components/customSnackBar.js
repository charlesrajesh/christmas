import { useState, useEffect, forwardRef } from "react";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from "@mui/material/Alert";
import Stack from "@mui/material/Stack";

const Alert = forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function CustomSnackBar() {
  const [alert, setAlert] = useState(true);
  const isGiftedAlready = JSON.parse(localStorage.getItem("gifted"));

  return (
    <>
      {alert && !isGiftedAlready && (
        <Stack spacing={2} sx={{ width: "80%" }}>
          <Snackbar
            anchorOrigin={{ vertical: "top", horizontal: "center" }}
            open={alert}
            onClose={() => setAlert(false)}
          >
            <Alert
              onClose={() => setAlert(false)}
              severity="success"
              sx={{ width: "100%" }}
            >
              Please find and click any grey balls and watch it turn into a surprise after presenting your voluntary gift !
            </Alert>
          </Snackbar>
        </Stack>
      )}
    </>
  );
}

export default CustomSnackBar;
