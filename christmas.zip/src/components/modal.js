import { useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { setModalVisibility, addOptedGift } from "../actions/modalAction";
import Button from "@mui/material/Button";

function Modal() {
  const isVisible = useSelector(
    (state) => state.reducer.modalReducer.isVisible
  );

  const modal = useRef({ current: null });
  const dispatch = useDispatch();

  function saveGiftRequest() {
    dispatch(addOptedGift());
    dispatch(setModalVisibility(false));
  }

  function modalClose() {
    dispatch(setModalVisibility(false));
  }
  window.onclick = function (event) {
    if (event.target === modal) {
      dispatch(setModalVisibility(false));
    }
  };

  return (
    <>
      {isVisible && (
        <div id="myModal" className="modal">
          <div className="modal-content">
            <span className="close" onClick={modalClose}>
              &times;
            </span>
            <div className="grid-container">
              <div className="grid-item">
                Please click below button and fill out the form. Merry
                Christmas!!!
              </div>
              <div className="grid-item">
                <Button variant="contained" onClick={saveGiftRequest}>
                  <a style={{"text-decoration": "none", color: "white", width:"100%", height: "100%", position : "absolute"}} href="https://forms.office.com/r/BpwJzL77iT" target="_blank" rel="noopener noreferrer">Gift</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Modal;
