export const divStyle = {
  display: "block",
  width: 100,
  height: 100,
  fontSize: "30px",
  fontWeight: "600",
  borderRadius: "10px",
};
