import imageListData from "../imageList.json";
import {
  setModalVisibility,
  setSelectedEleNode,
  getGiftData,
} from "../actions/modalAction";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";

function ImageContainer() {
  const dispatch = useDispatch();
  const optedGifts = useSelector(
    (state) => state.reducer.modalReducer.optedGifts
  );
  const selectedImageId = useSelector(
    (state) => state.reducer.modalReducer.selectedElementNode?.id
  );
  const isGiftedAlready = JSON.parse(localStorage.getItem("gifted"));

  function checkGiftOpted(id) {
    if (optedGifts.find((giftId) => giftId === id) !== undefined) return true;
    return false;
  }

  function prepareImageRender() {
    let data = [];
    data = imageListData.map((image) => {
      return { ...image, isOpted: checkGiftOpted(image.id) };
    });
    return data;
  }

  function handleClick(event) {
    if (!isGiftedAlready) {
      dispatch(setModalVisibility(true));
      dispatch(setSelectedEleNode(event.target));
    }
  }

  useEffect(() => {
    dispatch(getGiftData());
  }, []);

  function displayImage() {
    let data = imageList.map((image) => {
      if (image) {
        return (
          <image
            className={selectedImageId === image.id ? "selectedGift no-pointer" : "no-pointer"}
            id={image.id}
            key={image.id}
            x={image.x}
            y={image.y}
            width={image.width}
            height={image.height}
            href={image.path}
          />
        );
      } else {
        return (
          <image
            className={isGiftedAlready ? "no-pointer" : ""}
            id={image.id}
            key={image.id + "question"}
            x={image.x}
            y={image.y}
            width="25"
            height="25"
            onClick={handleClick}
            href={`assets/decor/question.svg`}
          />
        );
      }
    });
    return data;
  }

  const imageList = prepareImageRender();

  return <>{imageList && displayImage()}</>;
}

export default ImageContainer;
