import { combineReducers } from "redux";
import modalReducer from "./modalReducer";

const combinedReducers = combineReducers({ modalReducer });

export default combinedReducers;
