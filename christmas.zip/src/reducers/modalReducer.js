const initialState = {
  isVisible: false,
  selectedElementNode: null,
  optedGifts: [],
};

export default function (state = initialState, action) {
  const { type, payload } = action;
  switch (type) {
    case "SET_MODAL_VISIBILITY":
      return { ...state, isVisible: payload };
    case "SET_SELECTED_ELEMENT_NODE":
      return { ...state, selectedElementNode: payload };
    case "ADD_OPTED_GIFTS":
      return {
        ...state,
        optedGifts: payload,
      };
    case "SET_GIFT_DATA":
      return {
        ...state,
        optedGifts: payload,
      };
    default:
      return state;
  }
}
