import axios from "axios";

export function setModalVisibility(isVisible) {
  return { type: "SET_MODAL_VISIBILITY", payload: isVisible };
}

export function setSelectedEleNode(node) {
  return { type: "SET_SELECTED_ELEMENT_NODE", payload: node };
}

export function addOptedGift() {
  return function (dispatch, getState) {
    return new Promise((resolve, reject) => {
      const id = getState().reducer.modalReducer.selectedElementNode.id;
      const url = "http://10.203.38.183:8000/data/adddata";
      axios
        .post(url, { decoration: id })
        .then((Response) => {
          localStorage.setItem("gifted", "true");
          dispatch({
            type: "ADD_OPTED_GIFTS",
            payload: Response.data.decoration,
          });
          resolve(Response.data.decoration);
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        });
    });
  };
}

export const getGiftData = () => {
  return function (dispatch) {
    return new Promise((resolve, reject) => {
      const url = "http://10.203.38.183:8000/data/list";
      axios
        .get(url)
        .then((Response) => {
          dispatch({
            type: "SET_GIFT_DATA",
            payload: Response.data.decoration,
          });
          resolve(Response.data);
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        });
    });
  };
};
