﻿import "./App.css";
import SnowContainer from "./components/snowConatiner";
import ChristmasTree from "./components/christmasTree";
import ModalComponent from "./components/modal";
import AudioContainer from "./components/audioContainer";
import CustomSnackBar from "./components/customSnackBar";

function App() {
  const target = 25000;
  const collected = 25000;
  const calculatedColumnWidth = `${(collected / target) * 100}%`;

  return (
    <div className="App">
      <div className="container">
        <div className="bg-image"></div>
        
        <SnowContainer />
        <ChristmasTree />
        <div className="progress-bar-container">
          <div className="meter">
            <span style={{ width: calculatedColumnWidth }}></span>
            <div>Target: ₹{target}</div>
            <div>Amount collected: ₹{collected}</div>
          </div>
        </div>
      </div>
      <ModalComponent />
      <AudioContainer />
    </div>
  );
}

export default App;
